package com.Sixt.sistemas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class SixtApplication {

	public static void main(String[] args) {
		SpringApplication.run(SixtApplication.class, args);
	}

}
