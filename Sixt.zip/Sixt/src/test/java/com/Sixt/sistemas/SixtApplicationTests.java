package com.Sixt.sistemas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SixtApplicationTests {

	@Test
	void contextLoads() {
	}

}
